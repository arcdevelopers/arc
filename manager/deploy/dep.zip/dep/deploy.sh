#!/bin/bash



function start_server() {
        basepath=$(pwd)
        tbPath="/apache-tomcat-6.0.36/webapps"
        tomcatPath=${basepath}${tbPath} 
       
        cp -f jdbc.properties ${tomcatPath}/ROOT/WEB-INF
        cd apache-tomcat-6.0.36/bin

        sh startup.sh
}

function stop_server () {
        cd apache-tomcat-6.0.36/bin
        sh shutdown.sh
}

command=$1
shift 1
case $command in
    start)
        start_server $@;
        ;;    
    stop)
        stop_server $@;
        ;;
    restart)
        $0 stop $@
        $0 start $@
        ;;
    *)
        help;
        exit 1;
        ;;
esac
