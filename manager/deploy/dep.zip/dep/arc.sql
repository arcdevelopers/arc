CREATE TABLE `plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_name` varchar(45) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `money` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=未开始；1=进行中；2=成功；3=失败',
  `description` varchar(1024) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

CREATE TABLE `plan_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) NOT NULL,
  `plan_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=未开始；1=进行中；2=成功；3=失败',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

CREATE TABLE `plan_item_evidence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_item_id` int(11) NOT NULL,
  `avatar` varchar(128) DEFAULT NULL COMMENT '证据图片地址',
  `comment` varchar(1024) DEFAULT NULL COMMENT '证据说明',
  `created` datetime NOT NULL COMMENT '证据上传时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `plan_item_judge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_item_id` int(11) NOT NULL COMMENT '计划项id',
  `user_id` int(11) NOT NULL,
  `judge` tinyint(4) NOT NULL COMMENT '0=通过，1=反对',
  `comment` varchar(1024) DEFAULT NULL COMMENT '评论',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `plan_supervisor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(128) NOT NULL,
  `password` varchar(32) NOT NULL,
  `avatar` varchar(45) DEFAULT NULL,
  `balance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name_UNIQUE` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
